### IF.03.01 Procedural Programming Winter 2017

# Assignment: Chess

The first assignment dealing with multiple files and unit test.

Read the [problem statement](http://htmlpreview.github.com/?https://github.com/if-03-22-prpr/if.03.22-04_chess/blob/master/assignment/html/index.html) for further information.
